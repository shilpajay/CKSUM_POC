var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');

var multer = require('multer');
var fs = require('fs');


// var spawn = require('child_process').spawn;
// var child = spawn(cmd, args);


//Checksum Modules
var crc = require('crc');
var polycrc = require('polycrc');
var crcfull = require('crc-full');
var fastcrc32c = require('fast-crc32c');
var crc_32 = require('crc-32');
var cyclic_32 = require('cyclic-32');
var cksum = require('cksum');
var crchash = require('crc-hash');

var filename = '';
var storage = multer.diskStorage(
	{
		destination: './uploads/',
		filename: function (req, file, cb) {
			cb(null, file.originalname);
			filename = file.originalname;
		}
	}
);

var upload = multer({ storage: storage });

var app = express();



app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', function (req, res) {
	res.render('index', { title: 'Checksum Generator', fileStatus: '' });
});

app.post('/', upload.single('imageupload'), function (req, res) {
	console.log(filename);
	var checksumData = readFile();
	// writeOutputFile(checksumData);
	res.render('index', { fileStatus: 'File upload sucessfully.', checksumData: 'Output File has been created under outputs folder!' });
});

function readFile() {
	let tempFile = './uploads/' +filename;
	var options = {
		encoding: 'ascii'
	}
	var datas = fs.readFileSync(tempFile, options, function (err, data) {
		if (err) {
			console.log(err);
			throw err
		};
		console.log(data);
	});


	let checksumData ='';

	//CRC
	checksumData = checksumData + "MODULE: npm crc \n";
	checksumData = checksumData + "FUNCTION: crc32:  \n";
	checksumData = checksumData + crc.crc32(datas) + " \n \n \n \n"


	//POLYCRC
	checksumData = checksumData + "MODULE: npm polycrc \n";
	checksumData = checksumData + "FUNCTION: crc24:  \n";
	checksumData = checksumData + polycrc.crc24(datas) + " \n"
	checksumData = checksumData + "FUNCTION: crc32:  \n";
	checksumData = checksumData + polycrc.crc32(datas) + " \n"
	checksumData = checksumData + "FUNCTION: crc32c:  \n";
	checksumData = checksumData + polycrc.crc32c(datas) + " \n \n \n \n"

	//CRC-FULL MODULE OUTPUTS
	let dataType = "ascii";

	checksumData = checksumData + "MODULE: npm crcfull \n";

	checksumData = checksumData + "FUNCTION: CRC32:  \n";	
	checksumData = checksumData + crcfull.CRC.default("CRC32").compute(Buffer.from(datas, dataType)) + " \n"
	
	checksumData = checksumData + "FUNCTION: CRC32_BZIP2:  \n";
	checksumData = checksumData + crcfull.CRC.default("CRC32_BZIP2").compute(Buffer.from(datas, dataType)) + " \n"
	
	checksumData = checksumData + "FUNCTION: CRC32_C:  \n";
	checksumData = checksumData + crcfull.CRC.default("CRC32_C").compute(Buffer.from(datas, dataType)) + " \n"

	checksumData = checksumData + "FUNCTION: CRC32_D:  \n";
	checksumData = checksumData + crcfull.CRC.default("CRC32_D").compute(Buffer.from(datas, dataType)) + " \n"
	
	checksumData = checksumData + "FUNCTION: CRC32_MPEG2:  \n";
	checksumData = checksumData + crcfull.CRC.default("CRC32_MPEG2").compute(Buffer.from(datas, dataType)) + " \n"
	
	checksumData = checksumData + "FUNCTION: CRC32_POSIX:  \n";
	checksumData = checksumData + crcfull.CRC.default("CRC32_POSIX").compute(Buffer.from(datas, dataType)) + " \n"
	
	checksumData = checksumData + "FUNCTION: CRC32_Q:  \n";
	checksumData = checksumData + crcfull.CRC.default("CRC32_Q").compute(Buffer.from(datas, dataType)) + " \n"
	
	checksumData = checksumData + "FUNCTION: CRC32_JAMCRC:  \n";
	checksumData = checksumData + crcfull.CRC.default("CRC32_JAMCRC").compute(Buffer.from(datas, dataType)) + " \n"
	
	checksumData = checksumData + "FUNCTION: CRC32_XFER:  \n";
	checksumData = checksumData + crcfull.CRC.default("CRC32_XFER").compute(Buffer.from(datas, dataType)) + " \n \n \n \n"


	//fast-crc32c

	checksumData = checksumData + "MODULE: npm fast-crc32c \n";

	checksumData = checksumData + "FUNCTION: fastcrc32c.calculate:  \n";
	checksumData = checksumData + fastcrc32c.calculate(datas) + " \n \n \n \n"

	//crc-32

	checksumData = checksumData + "MODULE: npm crc-32 \n";

	checksumData = checksumData + "FUNCTION: crc_32.str:  \n";
	checksumData = checksumData + crc_32.str(datas) + " \n"

	checksumData = checksumData + "FUNCTION: crc_32.bstr:  \n";
	checksumData = checksumData + crc_32.bstr(datas) + " \n"

	checksumData = checksumData + "FUNCTION: crc_32.buf:  \n";
	checksumData = checksumData + crc_32.buf(datas) + " \n \n \n \n"

	//cyclic-32

	checksumData = checksumData + "MODULE: cyclic-32 \n";

	checksumData = checksumData + "FUNCTION: cyclic_32:  \n";
	checksumData = checksumData + cyclic_32(datas) + " \n \n \n \n"

	var cmdResult = null;

	// var sys = require('sys')
	var exec = require('child_process').exec;
	function puts(error, stdout, stderr) { 
		// sys.puts(stdout);
		console.log("In function");
		console.log(error);
		console.log(stderr);
		cmdResult = stdout;
		// checksumData = checksumData + "\n\n\n\n\n\n\n\n" + cmdResult;
		// writeOutputFile(checksumData);
		console.log(stdout);
	 }
	exec("cd outputs & certutil -hashfile package.json MD5", puts);


	//cksum

	// checksumData = checksumData + "MODULE: cksum \n";

	// checksumData = checksumData + "FUNCTION: cksum:  \n";
	// checksumData = checksumData + cksum(datas) + " \n \n \n \n"


	// console.log("MODULE: cksum");
	// console.log(cksum(new Buffer(datas)));

	//crc-hash crchash
	// console.log("MODULE: crc-hash");
	// var hash32 = crchash.createHash('crc32');

	// var dat = hash32.update(datas);
	// console.log(hash32.digest());

	
	return checksumData;
}

function writeOutputFile(data){
	var date= Date.now();
	fs.writeFile('./outputs/'+date+'-checksum.txt',data);
	renameProcessedFile();
}

function renameProcessedFile(){
	fs.rename('./uploads/' + filename , './uploads/' + 'processed_'+ Date.now() +'_' + filename);
	console.log("Renamed!!");
}

app.listen(3000);
console.log('>>>>> Server is running on port 3000...');